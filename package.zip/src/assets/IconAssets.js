import appLogo from "./ecom-logo.png";

export { appLogo };
